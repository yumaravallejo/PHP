<?php
    function letraNif($dni) {
     return substr("TRWAGMYFPDXBNJZSQVHLCKEO", $dni % 23, 1); 
    }

    function letra_valida($dni) {
        $letra_dada = substr($dni, -1, 1);
        if($letra_dada != letraNif($dni)){
            return false;
        } else return true;
    }

    function dni_valido($dni){
        $correcto = true;
        if (strlen($dni)!=9){
            $correcto = false;
        }

        for ($i = 0; $i < strlen($dni)-1; $i++) { //-1 para que coja solo los campos hasta la letra
            if(!is_numeric($dni[$i])){
                return false;
            }
        }

        if (!letra_valida($dni)) {
            $correcto = false;
        }

        return $correcto;
    }

    if(isset($_POST["guardar"])){
        //Compruebo errores del formulario
        $error_nombre=$_POST["nombre"]=="";
        $error_apellido=$_POST["apellidos"]=="";
        $error_clave=$_POST["contrasena"]=="";
        $error_dni=$_POST["dni"]=="" || !dni_valido($_POST['dni']);
        $error_sexo=!isset($_POST["sexo"]);
        $error_comentarios=$_POST["comentarios"]=="";

        $errores_form=$error_nombre||$error_apellido||$error_clave||$error_dni||$error_sexo||$error_comentarios;
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Práctica 1</title>
        <link rel="stylesheet" href="">
        <link rel="icon" href="img/rmescudo.png"> 
    </head>
    <style>
        .error {
            color: red;
        }
    </style>

<?php
    if(isset($_POST["guardar"]) && !$errores_form){      
        require "vistas/formulario.php";
    } else {
        require "vistas/formulario.php";
    }
    
?>
</html>