<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4 - Práctica con arrays</title>
</head>
<body>
    <h1>Imprimiendo con Print_r</h1>
    <p>[Posición] => Valor de la posición</p>
    <?php
        $array[] = "Pedro";
        $array[] = "Ana";
        $array[] = 34;
        $array[] = 1;

        print_r($array);
    ?>
</body>
</html>